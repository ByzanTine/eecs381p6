#include "View.h"

View::~View()
{
	
}